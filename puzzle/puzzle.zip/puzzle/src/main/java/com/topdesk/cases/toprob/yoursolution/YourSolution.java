package com.topdesk.cases.toprob.yoursolution;

import java.util.List;

import com.topdesk.cases.toprob.Grid;
import com.topdesk.cases.toprob.Instruction;
import com.topdesk.cases.toprob.Solution;

public class YourSolution implements Solution {
	@Override
	public List<Instruction> solve(Grid grid, int time) {
		throw new UnsupportedOperationException("Nothing implemented yet");
	}
}
